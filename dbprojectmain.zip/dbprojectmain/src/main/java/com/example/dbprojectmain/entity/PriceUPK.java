package com.example.dbprojectmain.entity;

import java.io.Serializable;

public class PriceUPK implements Serializable {
    private int comid;
    private String date;
}
