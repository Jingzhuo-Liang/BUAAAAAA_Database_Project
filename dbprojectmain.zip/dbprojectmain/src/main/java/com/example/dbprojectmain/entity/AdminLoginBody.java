package com.example.dbprojectmain.entity;

import lombok.Data;

@Data
public class AdminLoginBody {
  private String username;
  private String password;
}