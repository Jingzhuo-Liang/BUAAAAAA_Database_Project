package com.example.dbprojectmain.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

public class VisitUPK implements Serializable {
    private int userid;
    private LocalDateTime time;
}
